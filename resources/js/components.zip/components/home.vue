
<template>
    <div>


        <!--====== Start About Section ======-->
        <section class="about-area about-area-v1 position-relative pt-130">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="img-holder-box mb-50">


                            <div class="img-holder wow fadeInLeft" v-if="inicios.imagem_artigo==null || inicios.imagem_artigo==''">
                             <img src="/assets/images/about/about-1.jpg" alt="Image">
                            </div>

                            <div class="img-holder wow fadeInLeft" v-else>
                                <img :src="'levelschool/'+inicios.imagem_artigo" alt="Image">
                            </div>


                            <div class="shape shape-one">
                                <span class="animate-float-y"><img src="assets/images/shape/circle-logo-2.png"
                                        class="circle-logo" alt="circle logo"></span>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-wrapper mb-50 wow fadeInRight">
                            <div class="section-title mb-15">
                                <span class="sub-title st-one">Quem somos</span>
                                <h2>
                                    {{inicios.titulo}}
                                </h2>
                            </div>

                            <p>
                                {{ inicios.descricao }}
                            </p>


                        </div>
                    </div>
                </div>
            </div>
        </section>


        <section class="service-area pt-90 pb-80">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-title text-center mb-55 wow fadeInUp">
                            <!-- <span class="sub-title st-one">Serviços</span> -->
                            <h2> Nossos Produtos </h2>
                            <p> Tecnologias de Investigação e Desenvolvimento </p>
                        </div>
                    </div>
                </div>



                <div class="row justify-content-center">


                    <!-- <div v-for="(user, index) in users" :keys="index" style=" width:100%; "> -->
                    <!-- @click.prevent="showMessages(user.id); detalhe(user.id); "> -->

                    <div class="col-lg-3  col-md-6 col-sm-12 d-flex justify-content-center "
                        v-for="(segunda, index) in sedois" :keys="index">

                        <div class="service-item service-style-one  wow fadeInDown" data-wow-delay=".3s"
                            style="padding:30px 20px 20px;">
                            <div class="icon d-flex justify-content-center ">
                                <i :class="segunda.icone"></i>
                            </div>

                            <div class="">
                                <h3 class="title d-flex justify-content-center"><a class="text-align-center">
                                        {{ segunda.titulo }}
                                    </a></h3>

                                <ul class="">
                                    <li class="text-left">{{ segunda.descricao }}</li>
                                    <hr />

                                    <router-link :to="{ name: 'detalhe', params: { id: segunda.id }, hash: '#sectiontopo' }"
                                        class="nav-link d-flex justify-content-center">
                                        <span class="btn btn-primary">Saiba mais</span>
                                    </router-link>

                                </ul>

                                <!-- <a href="service-details.html" class="btn-link">Saiba Mais</a> -->

                            </div>
                        </div>


                    </div>




                </div>



            </div>
        </section>


    </div>
</template>



<script>


//import moment from 'moment';

export default {

    data() {

        return {

            inicios: [],
            sedois: []
            // messages: [],
            // selectedUserId: '',
            // single: '',
            //  css: "height:600px; width:30%; ",
            //  body:'',
            // moment:moment,
            // image:''
        }

    },


    mounted() {

        axios.get('/priseccao').then((response) => {
            this.inicios = response.data
            console.log(this.inicios);
        }),


            axios.get('/seguseccao').then((response) => {
                this.sedois = response.data

            })

        /*      setInterval(() => {
                this.showMessages(this.selectedUserId);
             },1000); */

        // this.detalhe();

    },

    methods: {}

}







</script>



