<template>
    <div>



        <!--====== Start Page-banner section ======-->
        <section class="page-banner bg_cover position-relative z-1">
            <div class="shape shape-one scene"><span data-depth="1"><img src="/assets/images/shape/shape-1.png"
                        alt=""></span></div>
            <div class="shape shape-two scene"><span data-depth="2"><img src="/assets/images/shape/shape-2.png"
                        alt=""></span></div>
            <div class="shape shape-three scene"><span data-depth="3"><img src="/assets/images/shape/shape-3.png"
                        alt=""></span></div>
            <div class="shape shape-four scene"><span data-depth="4"><img src="/assets/images/shape/shape-2.png"
                        alt=""></span></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-title">
                            <h1>Projectos da Level Soft</h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Início</a></li>
                                <li class="active">Projectos</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">

                        <div class="page-banner-img" v-if="priprojecto.imagem_artigo == null || priprojecto.imagem_artigo == ''">
                            <img src="/assets/images/breadcrumb/img-3.jpg" alt="">
                        </div>


                        <div class="page-banner-img" v-else>
                            <img :src="'levelschool/'+priprojecto.imagem_artigo" alt="Image">
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <!--====== Start Portfolio Section ======-->
        <section class="portfolio-area portfolio-area-v1 light-gray-bg pt-210 pb-130">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-title mb-45 text-center wow fadeInUp">
                            <!-- <span class="sub-title st-one">Latest Work</span> -->
                            <h2> Trabalhos já concebidos </h2>
                            <p>Tecnologias de Investigação e Desenvolvimento</p>
                        </div>
                    </div>
                </div>

                <!-- <div class="row">

                <div class="col-lg-12">
                    <div class="portfolio-filter-button text-center mb-40 wow fadeInUp">
                        <ul class="filter-btn mb-30">
                            <li data-filter="*" class="active">Show All</li>
                            <li data-filter=".cat-1">Design</li>
                            <li data-filter=".cat-2">Branding</li>
                            <li data-filter=".cat-3">Development</li>
                            <li data-filter=".cat-4">SEO</li>
                            <li data-filter=".cat-5">UX/UI Design</li>
                        </ul>
                    </div>
                </div>
            </div> -->

                <div class="row portfolio-grid">

                    <div class="col-lg-3 col-md-6 col-sm-12 portfolio-column cat-2 cat-4"
                        v-for="(seguprojecto, index) in seguprojectos" :keys="index">

                        <div class="portfolio-item portfolio-style-one mb-50 wow fadeInUp" data-wow-delay=".15s">
                            <div class="img-holder">
                                <img src="/assets/images/portfolio/img-2.jpg" alt="Img" class="estilo-img">
                                <a href="/assets/images/portfolio/img-2.jpg" class="portfolio-hover img-popup">
                                    <div class="hover-content">
                                        <i class="far fa-plus"></i>
                                    </div>
                                </a>
                            </div>
                            <div class="text cor_port">
                                <h3 class="title"><a href="project-details.html"> {{ seguprojecto.titulo }} </a></h3>
                                <a href="projects.html" class="cat-link"> {{ seguprojecto.descricao }} </a>





                                <router-link class="nav-link d-flex justify-content-center "
                                  style="border-top:1px solid #39f; margin-top:5px;"  :to="{name: 'infopro', params: {id: seguprojecto.id}, hash: '#sectiontopo'} ">
                                    <span class="btn btn-primary mt-2 ">Saiba mais</span>

                                </router-link>


                            </div>
                        </div>

                    </div>


                </div>


                <!--        <div class="row">
                <div class="col-lg-12">
                    <div class="button-box text-center wow fadeInUp">
                        <a href="projects.html" class="main-btn arrow-btn"> Ver mais </a>
                    </div>
                </div>
            </div> -->


            </div>
        </section>
        <!--====== End Portfolio Section ======-->



    </div>
</template>





<script>

export default {

    data() {

        return {

            priprojecto: [],
            seguprojectos: [],
        }
    },

    mounted() {

        axios.get('/priprojecto').then((response) => {
            this.priprojecto = response.data
            console.log(this.priprojecto);
        }),

            axios.get('/seguprojectos').then((response) => {
                this.seguprojectos = response.data
                console.log(this.seguprojectos);
            })

    },

    methods: {}
}

</script>

<style>
.portfolio-column {
    padding: 10px;
}

.cor_port {
    background: #fbfbfb;
    padding: 10px;
    border-bottom-left-radius: 7%;
    border-bottom-right-radius: 7%;
}


.estilo-img {
    border-top-left-radius: 7%;
    border-top-right-radius: 7%;
    border-top: 1px solid #ebebeb;
    border-left: 1px solid #ebebeb;
    border-right: 1px solid #ebebeb;
}
</style>

