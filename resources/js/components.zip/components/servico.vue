<template>
    <div>

        <!--====== Start Page-banner section ======-->
        <section class="page-banner bg_cover position-relative z-1">
            <div class="shape shape-one scene"><span data-depth="1"><img src="assets/images/shape/shape-1.png"
                        alt=""></span></div>
            <div class="shape shape-two scene"><span data-depth="2"><img src="assets/images/shape/shape-2.png"
                        alt=""></span></div>
            <div class="shape shape-three scene"><span data-depth="3"><img src="assets/images/shape/shape-3.png"
                        alt=""></span></div>
            <div class="shape shape-four scene"><span data-depth="4"><img src="assets/images/shape/shape-2.png"
                        alt=""></span></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-title">
                            <h1>Nossos serviços </h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Início</a></li>
                                <li class="active">Serviço</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">



                        <div class="page-banner-img"
                            v-if="prisecservico.imagem_artigo == null || prisecservico.imagem_artigo == ''">
                            <img src="assets/images/breadcrumb/img-2.jpg" alt="">
                        </div>

                        <div class="page-banner-img" v-else>
                            <img :src="'levelschool/' + prisecservico.imagem_artigo" alt="Image">
                        </div>




                    </div>
                </div>
            </div>
        </section><!--====== End Page-banner section ======-->

        <section class="fancy-text-block fancy-text-block-v2 pt-210 pb-90">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">






                        <div class="img-holder mb-50 wow fadeInLeft" data-wow-delay=".2s"
                            v-if="segusecservico.imagem_artigo == null || segusecservico.imagem_artigo == ''">
                            <img src="assets/images/about/img-5.png" alt="">
                        </div>


                        <div class="img-holder mb-50 wow fadeInLeft" data-wow-delay=".2s" v-else>
                            <img :src="'levelschool/' + segusecservico.imagem_artigo" alt="Image">
                        </div>




                    </div>

                    <div class="col-lg-6">
                        <div class="text-wrapper mb-50 wow fadeInRight" data-wow-delay=".4s">
                            <div class="section-title mb-30">
                                <h2>
                                    {{ segusecservico.titulo }}
                                </h2>

                            </div>
                            <p>

                                {{ segusecservico.descricao }}

                            </p>



                            <a href="about.html" class="main-btn arrow-btn"> Ver mais </a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End Fancy-text-block section ======-->
        <!--====== Start Features section ======-->

        <section class="features-area pt-70">
            <div class="container">
                <div class="row">


                    <div class="col-lg-12">

                        <div class="features-list mb-50 wow fadeInRight" v-for="(tercservico, index) in tercservicos"
                            :keys="index">


                            <div class="features-item mb-30">
                                <div class="text">
                                    <h4>Level-Learning</h4>
                                    <p>

                                        A Plataforma Level-Learning é uma solução de formação online que pode funcionar em
                                        modo síncrono e assíncrono num ambiente amigável e eficaz. Com a plataforma consegue
                                        fazer a gestão dos formandos e professores, a criação e gestão de cursos, a inserção
                                        de ficheiros e atividades e a gestão da formação, fazendo uso de técnicas de
                                        inovação nos métodos de ensino através de conceitos que vão além da aprendizagem
                                        tradicional. Ambiente colaborativo que possibilita estudo fácil e rápido para os
                                        alunos. Dispõe de uma boa base de dados estatísticos e gráficos de gestão


                                    </p>




                                </div>
                            </div>




                        </div>
                    </div>






                </div>
            </div>
        </section><!--====== End Features section ======-->

    </div>
</template>



<script>

//import moment from 'moment';

export default {

    data() {

        return {

            prisecservico: [],
            segusecservico: [],
            tercservicos: []
            // messages: [],
            // selectedUserId: '',
            // single: '',
            //  css: "height:600px; width:30%; ",
            //  body:'',
            // moment:moment,
            // image:''
        }

    },


    mounted() {

        axios.get('/prisecservico').then((response) => {
            this.prisecservico = response.data
            console.log(this.prisecservico);
        }),


            axios.get('/segusecservico').then((response) => {
                this.segusecservico = response.data
                console.log(this.segusecservico);
            }),


            axios.get('/tercservicos').then((response) => {
                this.tercservicos = response.data
                console.log(this.tercservicos);
            })



    },

    methods: {}

}


</script>

